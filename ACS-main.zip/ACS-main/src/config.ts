export const SHUFFLE_CONFIG = {
  minVariations: 250,
  prefixes: ['050', '054', '056', '052', '055']
} as const;