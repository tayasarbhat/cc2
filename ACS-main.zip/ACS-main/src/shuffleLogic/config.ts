export const SHUFFLE_CONFIG = {
  prefixes: ['050', '054', '056', '052', '055'],
  minVariations: 250,
  maxDigits: 10
};